package com.mrahmed.HRandPMSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HRandPmSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HRandPmSystemApplication.class, args);
	}

}
