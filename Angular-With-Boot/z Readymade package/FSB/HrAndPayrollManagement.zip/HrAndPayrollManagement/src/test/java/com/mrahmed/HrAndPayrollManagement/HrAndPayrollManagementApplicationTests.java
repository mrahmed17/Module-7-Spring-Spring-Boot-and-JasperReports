package com.mrahmed.HrAndPayrollManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrAndPayrollManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
