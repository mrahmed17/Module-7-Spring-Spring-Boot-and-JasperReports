package com.mrahmed.HrAndPayrollManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrAndPayrollManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrAndPayrollManagementApplication.class, args);
	}

}
