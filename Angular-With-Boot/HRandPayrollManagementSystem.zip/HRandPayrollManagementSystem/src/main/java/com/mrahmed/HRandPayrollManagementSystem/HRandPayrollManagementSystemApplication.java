package com.mrahmed.HRandPayrollManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HRandPayrollManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HRandPayrollManagementSystemApplication.class, args);
	}

}
