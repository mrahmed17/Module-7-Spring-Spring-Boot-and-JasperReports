package com.mrahmed.ReviewSprintBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewSprintBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
